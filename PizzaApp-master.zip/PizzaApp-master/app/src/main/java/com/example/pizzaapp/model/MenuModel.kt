package com.example.pizzaapp.model

import android.graphics.Bitmap

class MenuModel(var id:Int, var name:String, var price:Int, var image:Bitmap)

